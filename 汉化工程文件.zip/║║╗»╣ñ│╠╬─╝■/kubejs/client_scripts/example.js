ItemEvents.tooltip(event => {
  event.add(['unusual_meme_shoes:duck_shoes_boots'], '§7快冷静点，直到我把你制服')
  event.add(['unusual_meme_shoes:rare_boots'], '§7唉... 终于喘口气了！')
  event.add(['unusual_meme_shoes:drip_boots'], '§7这些本应该和黑色卫衣一起穿')
  event.add(['createsifter:brass_sifter', 'createsifter:advanced_brass_mesh', 'createsifter:dust', 'createsifter:crushed_end_stone', 'createutilities:void_battery', 'unusual_meme_shoes:clown_boots', 'unusual_meme_shoes:duck_shoes_boots', 'unusual_meme_shoes:wednesday_boots', 'unusual_meme_shoes:v_2_boots'], '§5此 §5物品 §5在 §5此 §5模组包 §5中 §5已被禁用')
})


