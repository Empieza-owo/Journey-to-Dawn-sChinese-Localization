ClientEvents.lang('ru_ru', event => {
    // need a separate event for each lang code, replace 'en_us' with appropriate language code above
      event.renameItem('kubejs:warped_crown', '扭曲的皇冠')
    })